package app.story.model;

public enum Kind {
    FIRST, SECOND, THIRD, FOURTH
}
